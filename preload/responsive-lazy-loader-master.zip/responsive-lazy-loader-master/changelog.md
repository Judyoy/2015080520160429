responsive-lazy-loader
======================

##O.1.8 : 

Allow to override windowView function to allow developpers to deal with custom positionning.

##O.1.7 : 

Allow to override image url for specific display and/or breakpoint.

##O.1.6 : 

Allow to use gridClass on image itself.
Fix chain function issue.
Readme update.

##O.1.5 : 

Update mainfest.

##O.1.4 : 

Parent became optional, gridClass will be used if parent is not specified.

##O.1.3 : 

English updates.

##O.1.2 : 

Update mainfest

##O.1.1 : 

Fix issue on tag.

##O.1.0 : 

Fix name issue in manifest.
