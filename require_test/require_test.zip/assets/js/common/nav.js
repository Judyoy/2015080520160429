define(['jquery'], function($){
    $.nav = function () {
        alert('i am a jquery.nav');
    }
});